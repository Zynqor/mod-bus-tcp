#!/bin/bash

reboot
